package com.ultimategroup.phasal

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class ForumActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.there_is_nothing_to_show)
    }
}
