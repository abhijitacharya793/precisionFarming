package com.ultimategroup.phasal.Model

class Group {

}